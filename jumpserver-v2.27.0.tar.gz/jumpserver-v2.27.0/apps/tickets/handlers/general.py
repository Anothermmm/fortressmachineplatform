from .base import BaseHandler


class Handler(BaseHandler):
    pass
